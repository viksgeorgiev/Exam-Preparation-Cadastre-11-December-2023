﻿namespace Cadastre.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Cadastre2025;Trusted_Connection=True;";
    }
}
